package com.example.demo.config;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

@Configuration
@Order(Ordered.HIGHEST_PRECEDENCE)
@EnableJpaRepositories(basePackages = {
		"com.example.demo.master.repository" }, entityManagerFactoryRef = "entityManagerFactory2", transactionManagerRef = "transactionManager2")
public class JPAConfig2 {

	@Autowired
	@Qualifier("dataSource")
	private DataSource dataSource;

	@Bean("entityManagerFactory2")
	@Primary
	protected LocalContainerEntityManagerFactoryBean entityManagerFactory() {
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setGenerateDdl(true);
//		vendorAdapter.setShowSql(true);
		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
		factory.setJpaVendorAdapter(vendorAdapter);
		factory.setPackagesToScan("com.example.demo.master.model");
		factory.setDataSource(dataSource);
		factory.setJpaPropertyMap(hibernateProperties());
		return factory;
	}

	@Bean("transactionManager2")
	@Primary
	protected JpaTransactionManager transactionManager() {
		JpaTransactionManager txManager = new JpaTransactionManager();
		txManager.setEntityManagerFactory(entityManagerFactory().getObject());
		return txManager;
	}

	private Map<String, Object> hibernateProperties() {
		Map<String, Object> hibernateProperties = new HashMap<>();

		hibernateProperties.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
		// Add other properties as needed
		return hibernateProperties;
	}
}
