package com.example.demo.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;

import com.example.demo.master.config.TenantContext;
import com.example.demo.master.model.Tenant;
import com.example.demo.master.repository.TenantRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class CustomInterceptor implements HandlerInterceptor {

	private final TenantRepository tenantRepository;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		String tenantId = request.getHeader("tenant");
		Tenant tenant = tenantRepository.findByUniqueId(tenantId)
				.orElseThrow(() -> new IllegalArgumentException("Invalid Tenant"));
		TenantContext.setCurrentTenantId(tenant.getPoolName());
//		TenantContext.setCurrentTenantId(tenantId);

		return true;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		TenantContext.clear();
	}
}
