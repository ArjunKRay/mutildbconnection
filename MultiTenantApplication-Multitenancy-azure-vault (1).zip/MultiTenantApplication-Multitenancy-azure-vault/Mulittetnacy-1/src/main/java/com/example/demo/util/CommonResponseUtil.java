package com.example.demo.util;

import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.demo.dto.CommonResponseDTO;

@Service
public class CommonResponseUtil {

	private static final String SUCCESS = "Success";
	private static final String FAILED = "Failed";
	private static final String EXCEPTION = "Expectation Failed";
	private static final String BADREQUEST = "Bad Request";
	private static final String NOCONTENT = "No Content";
	private static final String UNAUTHORIZED = "Unauthorized";
	private static final String STATUS401 = "401";
	private static final String STATUS200 = "200";
	private static final String STATUS400 = "400";
	private static final String STATUS417 = "417";
	private static final String STATUS204 = "204";

	public ResponseEntity<CommonResponseDTO> getSuccessResponse(Object response) {
		CommonResponseDTO responseDTO = new CommonResponseDTO();
		responseDTO.setResponse(SUCCESS);
		responseDTO.setStatus(SUCCESS);
		responseDTO.setStatusCode(STATUS200);
		responseDTO.setMessage("");
		responseDTO.setData(response);
		return ResponseEntity.status(HttpStatus.OK).body(responseDTO);
	}

	public ResponseEntity<CommonResponseDTO> getBadRequestResponse(String message) {
		CommonResponseDTO responseDTO = new CommonResponseDTO();
		responseDTO.setResponse(FAILED);
		responseDTO.setStatus(BADREQUEST);
		responseDTO.setStatusCode(STATUS400);
		responseDTO.setMessage(message);
		responseDTO.setData(new HashMap<>());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(responseDTO);
	}

	public ResponseEntity<CommonResponseDTO> getExceptionResponse(Exception e) {
		CommonResponseDTO responseDTO = new CommonResponseDTO();
		responseDTO.setResponse(FAILED);
		responseDTO.setStatus(EXCEPTION);
		responseDTO.setStatusCode(STATUS417);
		responseDTO.setMessage(e.toString());
		responseDTO.setData(new HashMap<>());
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(responseDTO);
	}

	public ResponseEntity<CommonResponseDTO> getNoContentResponse(String message) {
		CommonResponseDTO responseDTO = new CommonResponseDTO();
		responseDTO.setResponse(FAILED);
		responseDTO.setStatus(NOCONTENT);
		responseDTO.setStatusCode(STATUS204);
		responseDTO.setMessage(message);
		responseDTO.setData(new HashMap<>());
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(responseDTO);
	}

	public ResponseEntity<CommonResponseDTO> getUnauthorizedResponse(String message) {
		CommonResponseDTO responseDTO = new CommonResponseDTO();
		responseDTO.setResponse(FAILED);
		responseDTO.setStatus(UNAUTHORIZED);
		responseDTO.setStatusCode(STATUS401);
		responseDTO.setMessage(message);
		responseDTO.setData(new HashMap<>());
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body(responseDTO);
	}

}
