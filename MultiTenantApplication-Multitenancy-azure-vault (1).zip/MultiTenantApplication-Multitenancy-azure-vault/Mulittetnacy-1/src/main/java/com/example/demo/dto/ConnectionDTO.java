package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ConnectionDTO {

	private String name;
	private String databaseUrl;
	private String username;
	private String password;
	private String driverClass;
	private String databaseType;
	private Integer maxPoolSize;
	private Integer connectionTimeOut;
	private Integer minimumIdeal;
	private Integer idleTimeOut;
	private String ddlAuto;

}
