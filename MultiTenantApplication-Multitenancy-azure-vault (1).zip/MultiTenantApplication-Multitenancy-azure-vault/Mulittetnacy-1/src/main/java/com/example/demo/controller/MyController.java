package com.example.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CommonResponseDTO;
import com.example.demo.dto.UserDTO;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/demo")
@RequiredArgsConstructor
public class MyController {

	private final UserService userService;

	@GetMapping("/get-all")
	public ResponseEntity<CommonResponseDTO> getData() {
		return this.userService.getAllData();

	}

	@PostMapping("/add")
	public ResponseEntity<CommonResponseDTO> addData(HttpServletRequest request, @RequestBody UserDTO userDTO) {
		return this.userService.addData(request, userDTO);
	}

	
}
