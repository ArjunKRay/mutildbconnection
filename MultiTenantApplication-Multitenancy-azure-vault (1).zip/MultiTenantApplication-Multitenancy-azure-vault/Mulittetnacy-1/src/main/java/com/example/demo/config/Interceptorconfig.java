package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.example.demo.interceptor.CustomInterceptor;
import com.example.demo.master.repository.TenantRepository;

@Configuration
public class Interceptorconfig {

	@Bean
	protected WebMvcConfigurer getWebMvcConfigurer(TenantRepository tenantRepository) {
		return new WebMvcConfigurer() {
			@Override
			public void addInterceptors(InterceptorRegistry registry) {
				registry.addInterceptor(new CustomInterceptor(tenantRepository)).addPathPatterns("/demo/**");
			}
		};
	}
}
