package com.example.demo.config;

import org.jasypt.util.text.BasicTextEncryptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UtilConfig {

	@Bean
	protected BasicTextEncryptor getBasicTextEncryptor() {
		BasicTextEncryptor textEncryptor = new BasicTextEncryptor();
		textEncryptor.setPasswordCharArray("BDO_SFTP_ENCRYPT".toCharArray());
		return textEncryptor;
	}
}
