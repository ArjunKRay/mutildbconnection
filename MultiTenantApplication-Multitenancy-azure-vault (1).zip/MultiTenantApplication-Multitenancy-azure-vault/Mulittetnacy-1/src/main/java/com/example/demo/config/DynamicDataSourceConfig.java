package com.example.demo.config;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.DataSource;

import org.jasypt.util.text.TextEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.demo.dto.ConnectionDTO;
import com.example.demo.master.config.DynamicRoutingDataSource;
import com.example.demo.master.model.Tenant;
import com.example.demo.master.repository.TenantRepository;
import com.example.demo.util.AzureKeyVaultUtil;
import com.example.demo.util.CommonUtil;
import com.zaxxer.hikari.HikariDataSource;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class DynamicDataSourceConfig {

	private final TextEncryptor textEncryptor;
	private final TenantRepository tenantRepository;
	private final AzureKeyVaultUtil azureKeyVaultUtil;
	private final CommonUtil commonUtil;

	private Map<String, String> tenantDBTypeMap;

	@Autowired
	@Qualifier("dataSource")
	private DataSource dataSource;

	@Bean("dynamicDataSource")
	protected DataSource dynamicDataSource() {
		DynamicRoutingDataSource dynamicRoutingDataSource = new DynamicRoutingDataSource();
		Map<Object, Object> resolvedDataSources = new ConcurrentHashMap<>();
		List<Tenant> tenants = tenantRepository.findAll();
		for (Tenant tenant : tenants) {
			if (!resolvedDataSources.containsKey(tenant.getPoolName())) {
				ConnectionDTO connectionDTO = commonUtil.jsonToObject(
						textEncryptor.decrypt(azureKeyVaultUtil.getDataFromVault(tenant.getVaultKey())),
						ConnectionDTO.class);
				resolvedDataSources.put(tenant.getPoolName(), this.createTenantDataSource(connectionDTO));
			}

		}
//		Map<Object, Object> resolvedDataSources = tenants.stream().collect(Collectors.toMap(ConnectionDTO::getName,
//				this::createTenantDataSource, (o, n) -> n, ConcurrentHashMap::new));

//		Create concurrentHashmap and pool name as key and DataSource as Value
		dynamicRoutingDataSource.setDefaultTargetDataSource(
				!tenants.isEmpty() ? resolvedDataSources.get(tenants.get(tenants.size() - 1).getPoolName())
						: dataSource);
		dynamicRoutingDataSource.setTargetDataSources(resolvedDataSources);
		dynamicRoutingDataSource.afterPropertiesSet();
		return dynamicRoutingDataSource;
	}

	private HikariDataSource createTenantDataSource(ConnectionDTO connectionDTO) {
		HikariDataSource hikariDataSource = new HikariDataSource();
		hikariDataSource.setJdbcUrl(textEncryptor.decrypt(connectionDTO.getDatabaseUrl()));
		hikariDataSource.setUsername(textEncryptor.decrypt(connectionDTO.getUsername()));
		hikariDataSource.setPassword(textEncryptor.decrypt(connectionDTO.getPassword()));
		hikariDataSource.setDriverClassName(textEncryptor.decrypt(connectionDTO.getDriverClass()));
		hikariDataSource.setMaximumPoolSize(connectionDTO.getMaxPoolSize());
		hikariDataSource.setIdleTimeout(connectionDTO.getIdleTimeOut());
		hikariDataSource.setMinimumIdle(connectionDTO.getMinimumIdeal());
//		hikariDataSource.setConnectionTimeout(connectionDTO.getConnectionTimeOut());
		hikariDataSource.setPoolName(textEncryptor.decrypt(connectionDTO.getName()) + "'s Pool");
		return hikariDataSource;
	}

	@Bean
	protected JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate(dynamicDataSource());
	}

	public Map<String, String> getTenantDBTypeMap() {
		return tenantDBTypeMap;
	}

}
