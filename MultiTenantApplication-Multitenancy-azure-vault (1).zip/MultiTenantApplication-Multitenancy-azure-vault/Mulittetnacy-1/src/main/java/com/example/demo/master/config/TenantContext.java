package com.example.demo.master.config;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TenantContext {
	private static final ThreadLocal<String> currentTenant = new ThreadLocal<>();

	public static void setCurrentTenantId(String tenantId) {
		currentTenant.set(tenantId);
	}

	public static String getCurrentTenantId() {
		return currentTenant.get();
	}

	public static void clear() {
		currentTenant.remove();
	}
}
