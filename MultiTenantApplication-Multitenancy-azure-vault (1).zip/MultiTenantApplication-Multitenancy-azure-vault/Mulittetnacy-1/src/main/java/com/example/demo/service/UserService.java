package com.example.demo.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.dto.CommonResponseDTO;
import com.example.demo.dto.UserDTO;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.util.CommonResponseUtil;
import com.example.demo.util.CommonUtil;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserService {

	private final JdbcTemplate jdbcTemplate;

	private final UserRepository userRepository;

	private final CommonUtil commonUtil;

	private final CommonResponseUtil commonResponseUtil;

	public ResponseEntity<CommonResponseDTO> getAllData() {
		try {
			List<User> findAll = userRepository.findAll();
			if (findAll != null && !findAll.isEmpty()) {
				return this.commonResponseUtil.getSuccessResponse(findAll);
			} else {
				return this.commonResponseUtil.getNoContentResponse("Not Found");
			}
		} catch (Exception e) {
			log.error("getAllData >> Exception :: {}", e.toString());
			return this.commonResponseUtil.getExceptionResponse(e);
		}
	}

	@PostMapping("/add")
	public ResponseEntity<CommonResponseDTO> addData(HttpServletRequest request, @RequestBody UserDTO userDTO) {
		log.info("addData >> user :: {}", userDTO.toString());
//		Optional<User> userOptional = userRepository.findById(user.getId());
		try {
			this.commonUtil.delayForSeconds(5);
//		if (userOptional.isPresent())
//			return new ResponseEntity<>("Already exist", HttpStatus.CONFLICT);
//		else {
			User user = User.builder().name(userDTO.getName()).department(userDTO.getDepartment())
					.addDate(commonUtil.getTimeByRequest(request)).build();
			return this.commonResponseUtil.getSuccessResponse(userRepository.save(user));
//		}
		} catch (Exception e) {
			log.error("addData >> Exception :: {}", e.toString());
			return this.commonResponseUtil.getExceptionResponse(e);
		}
	}

}
