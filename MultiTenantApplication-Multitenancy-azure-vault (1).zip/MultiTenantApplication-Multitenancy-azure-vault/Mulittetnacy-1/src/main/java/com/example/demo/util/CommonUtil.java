package com.example.demo.util;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CommonUtil {

	public Date getTimeByZoneId(String zoneIdStr) {
		try {
			ZonedDateTime utcDateTime = ZonedDateTime.now(ZoneOffset.UTC);
			ZoneId zoneId = ZoneId.of(zoneIdStr);
			ZonedDateTime zonedDateTime = utcDateTime.withZoneSameInstant(zoneId);
			String pattern = "yyyy-MM-dd HH:mm:ss";
			return new SimpleDateFormat(pattern).parse(zonedDateTime.format(DateTimeFormatter.ofPattern(pattern)));
		} catch (Exception e) {
			log.error("getTimeByZoneId >> Exception :: {} >>  ZoneId :: {}", e.toString(), zoneIdStr);
			return new Date();
		}
	}

	public Date getTimeByRequest(HttpServletRequest request) {
		String zoneIdStr = request.getHeader("zoneId");
		try {
			ZonedDateTime utcDateTime = ZonedDateTime.now(ZoneOffset.UTC);
			ZoneId zoneId = ZoneId.of(zoneIdStr);
			ZonedDateTime zonedDateTime = utcDateTime.withZoneSameInstant(zoneId);
			String pattern = "yyyy-MM-dd HH:mm:ss";
			return new SimpleDateFormat(pattern).parse(zonedDateTime.format(DateTimeFormatter.ofPattern(pattern)));
		} catch (Exception e) {
			log.error("getTimeByRequest >> Exception :: {} >>  ZoneId :: {}", e.toString(), zoneIdStr);
			return new Date();
		}
	}

	public void delayForSeconds(int seconds) {
		try {
			Thread.sleep(seconds * 1000L);
		} catch (Exception e) {
			log.error("delayForSeconds >> sleep Exception :: {}", e.toString());
		}
	}

	public <T> String objectToJsonString(T object) {
		try {
			return new ObjectMapper().writeValueAsString(object);
		} catch (Exception e) {
			log.error("objectToJsonString >> Exception :: {}", e.toString());
			return "";
		}
	}

	public <T> T jsonToObject(String json, Class<T> clazz) {
		try {
			return new ObjectMapper().readValue(json, clazz);
		} catch (Exception e) {
			log.error("objectToJsonString >> Exception :: {}", e.toString());
			return null;
		}
	}

//	public static void main(String[] args) {
//		CommonUtil util = new CommonUtil();
//		Tenant tenant = Tenant.builder().id(1).databaseUrl("dsascscs").driverClass("driver").name("name")
//				.password("password").build();
//		System.out.println(util.objectToJsonString(tenant));
//		Tenant tenant1 =util.jsonToObject(util.objectToJsonString(tenant), Tenant.class);
//		System.out.println(tenant1);
//	}

}
