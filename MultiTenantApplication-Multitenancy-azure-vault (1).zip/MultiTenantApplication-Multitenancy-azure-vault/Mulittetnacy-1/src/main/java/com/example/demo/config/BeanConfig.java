package com.example.demo.config;

import javax.sql.DataSource;

import org.jasypt.util.text.TextEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import com.example.demo.dto.ConnectionDTO;
import com.example.demo.util.AzureKeyVaultUtil;
import com.example.demo.util.CommonUtil;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class BeanConfig {

	@Autowired
	private AzureKeyVaultUtil azureKeyVaultUtil;

	@Autowired
	private CommonUtil commonUtil;

	@Autowired
	private TextEncryptor textEncryptor;

	private ConnectionDTO getDataFromVault(String secretName) {
		return commonUtil.jsonToObject(textEncryptor.decrypt(azureKeyVaultUtil.getDataFromVault(secretName)),
				ConnectionDTO.class);
	}

	@Primary
	@Bean("dataSource")
	protected DataSource defaultDataSource() {
		return this.createTenantDataSource(this.getDataFromVault("master"));
	}

	private HikariDataSource createTenantDataSource(ConnectionDTO connectionDTO) {
		HikariDataSource hikariDataSource = new HikariDataSource();
		hikariDataSource.setJdbcUrl(textEncryptor.decrypt(connectionDTO.getDatabaseUrl()));
		hikariDataSource.setUsername(textEncryptor.decrypt(connectionDTO.getUsername()));
		hikariDataSource.setPassword(textEncryptor.decrypt(connectionDTO.getPassword()));
		hikariDataSource.setDriverClassName(textEncryptor.decrypt(connectionDTO.getDriverClass()));
		hikariDataSource.setMaximumPoolSize(connectionDTO.getMaxPoolSize());
		hikariDataSource.setIdleTimeout(connectionDTO.getIdleTimeOut());
		hikariDataSource.setMinimumIdle(connectionDTO.getMinimumIdeal());
		hikariDataSource.setPoolName(textEncryptor.decrypt(connectionDTO.getName()) + "'s Pool");
		return hikariDataSource;
	}

	@Bean
	protected JdbcTemplate jdbcTemplateMaster() {
		return new JdbcTemplate(defaultDataSource());
	}

}
