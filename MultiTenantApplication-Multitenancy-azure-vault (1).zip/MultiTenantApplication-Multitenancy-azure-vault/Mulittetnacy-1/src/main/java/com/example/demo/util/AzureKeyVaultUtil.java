package com.example.demo.util;

import org.jasypt.util.text.BasicTextEncryptor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.azure.core.util.polling.SyncPoller;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.DeletedSecret;

import lombok.RequiredArgsConstructor;

@Order(Ordered.HIGHEST_PRECEDENCE)
@Component
@RequiredArgsConstructor
public class AzureKeyVaultUtil {

	@Value("${azure.vaultUrl}")
	private String vaultUrl;

	@Value("${azure.tenantId}")
	private String tenantId;

	@Value("${azure.clientId}")
	private String clientId;

	@Value("${azure.clientSecret}")
	private String clientSecret;

	private final BasicTextEncryptor textEncryptor;

	private SecretClient getSecretClient() {
		ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
				.clientId(textEncryptor.decrypt(clientId)).clientSecret(textEncryptor.decrypt(clientSecret))
				.tenantId(textEncryptor.decrypt(tenantId)).build();
		return new SecretClientBuilder().vaultUrl(textEncryptor.decrypt(vaultUrl)).credential(clientSecretCredential).buildClient();

	}

	public String getDataFromVault(String secretName) {
		return this.getSecretClient().getSecret(secretName).getValue();
	}

	public void deleteVaultPassword(String secretName) {
		SyncPoller<DeletedSecret, Void> deletionPoller = this.getSecretClient().beginDeleteSecret(secretName);
		deletionPoller.waitForCompletion();
	}

	public void addInVault(String secretName, String secretValue) {
		this.getSecretClient().setSecret(secretName, secretValue);
	}

}
